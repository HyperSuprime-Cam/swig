// i add this file because it's referenced by other files.
// someone should replace these comments w/ proper content.
//   --ttn, 2001/01/16 17:44:19
