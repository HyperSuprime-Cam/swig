use imports_b;
use imports_a;

$x = imports_bc::new_B();
imports_ac::A_hello($x);
