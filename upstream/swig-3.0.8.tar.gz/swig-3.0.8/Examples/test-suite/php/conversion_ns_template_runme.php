<?php

require "tests.php";
require "conversion_ns_template.php";

check::classes(array("conversion_ns_template","Foo_One","Bar_One","Hi"));
// this is too hard, I'm not sure what to test for,

check::done();
?>
