#ifndef PY2_PKG2_BAR_HPP
#define PY2_PKG2_BAR_HPP
#include "../../py2/pkg2/pkg3/foo.hpp"
struct Pkg2_Bar : Pkg3_Foo {};
#endif /* PY2_PKG2_BAR_HPP */
