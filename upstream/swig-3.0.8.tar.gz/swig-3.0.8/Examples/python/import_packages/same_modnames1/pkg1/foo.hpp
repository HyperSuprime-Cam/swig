#ifndef PKG1_FOO_HPP
#define PKG1_FOO_HPP
struct Pkg1_Foo{};
#endif /* PKG1_FOO_HPP */
